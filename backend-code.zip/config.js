module.exports = {
    email: {
        host: 'smtp.163.com',
        port: 465,
        user: 'ccv2longdeploy@163.com',
        pass: 'sapcxpsl2',
    },

    recipient: [
    { emailAddress: '1249881412@qq.com'},
    { emailAddress: 'xiaoqing.sun@sap.com' },
    { emailAddress: 'tao.jiang02@sap.com' },
    { emailAddress: 'carry.lin@sap.com' },
    { emailAddress: 'winston.zhou@sap.com' },
    { emailAddress: 'yuping.shi@sap.com' },
    { emailAddress: 'timothy.li@sap.com' },
    { emailAddress: 'qing.liu03@sap.com' },
    { emailAddress: 'ireneusz.niedbala@sap.com' },
    { emailAddress: 'simon.song@sap.com' },
    { emailAddress: 'martin.hu@sap.com;' },
    { emailAddress: 'lucas.xu@sap.com;' },
    { emailAddress: 'fenghu.zhang@sap.com' },
    { emailAddress: 'david.jiang01@sap.com' },
    { emailAddress: 'john.jiang06@sap.com' },
    { emailAddress: 'wallace.zhao@sap.com' },
    { emailAddress: 'gerard.liu@sap.com' },
    ]
}
